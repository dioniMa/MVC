﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace MVCProject.Models
{
    public class Product
    {
        public Product()
        {
            Categories = new List<Category>();
        }

        [Key]
        public int ProductId { get; set; }
        [Required(ErrorMessage = "Product Name is required")]
        [Display(Name = "Product Name")]
        [MaxLength(50)]
        public string ProductName { get; set; }

        [Required(ErrorMessage = "Description is required")]
        [Display(Name = "Description")]
        [StringLength(2000, ErrorMessage = "String must not be longer than 2000", MinimumLength = 30)]
        public string Description { get; set; }
        public int CategoryId { get; set; }
        public List<Category> Categories { get; set; }
        public float Price { get; set; }
        public int UnitsInStock { get; set; }
       
        
    }
}
