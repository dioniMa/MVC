﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace MVCProject.Models
{
    public class Order
    {
        public Order()
        {
            Products = new List<Product>();
        }
        [Key]
        public int OrderId { get; set; }
        public int ProductId { get; set; }
        public List<Product> Products { get; set; }

        public float Price{ get; set; }
        public int Quantity { get; set; }
    }
}

